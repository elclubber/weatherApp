export const API_URLS = {
    GET_WEATHER: 'http://api.openweathermap.org/data/2.5/weather?q='
};

export const API_KEY = 'f825344b0cf0672c689378549f9868db';
